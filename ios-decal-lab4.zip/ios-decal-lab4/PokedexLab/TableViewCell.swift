//
//  TableViewCell.swift
//  PokedexLab
//
//  Created by Zeyana Ayesha Musthafa on 10/11/17.
//  Copyright © 2017 iOS Decal. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var tableimageView: UIImageView!
    
    @IBOutlet var pokemonNo: UILabel!
    @IBOutlet var pokemonName: UILabel!
    
    @IBOutlet var pokemonStats: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
