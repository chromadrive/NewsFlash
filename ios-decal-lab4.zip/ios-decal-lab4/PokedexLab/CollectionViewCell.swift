//
//  CollectionViewCell.swift
//  PokedexLab
//
//  Created by Zeyana Ayesha Musthafa on 10/11/17.
//  Copyright © 2017 iOS Decal. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var imageView: UIImageView!
}
